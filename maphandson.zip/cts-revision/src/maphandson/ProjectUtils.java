package maphandson;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;

public class ProjectUtils {

	public static TreeMap<Project, Employee> project() throws ParseException{
		// TODO Auto-generated method stub
Employee e1= new Employee(101,"Anusha",50000.00,"anu@gmail.com");
Employee e2= new Employee(102,"Kavya sri",45000.00,"kavya@gmail.com");
Employee e3= new Employee(103,"Bhavitha",60000.00,"bhavi@gmail.com");
Employee e4= new Employee(104,"Kankshitha",47000.00,"kankshi@gmail.com");
Employee e5= new Employee(105,"Uma",53000.00,"uma@gmail.com");
Employee e6= new Employee(106,"Gowtham",35000.00,"gowtham@gmail.com");
Employee e7= new Employee(107,"Karun",75000.00,"karun@gmail.com");
Employee e8= new Employee(108,"Sharanya",25000.00,"sharu@gmail.com");
Employee e9= new Employee(109,"Archana",40000.00,"archi@gmail.com");
Employee e10= new Employee(110,"Bhavani",55000.00,"bhav@gmail.com");
	
	SimpleDateFormat sdf= new SimpleDateFormat("dd-mm-yyyy"); 
	
	
	
Project p1= new Project(1,"Java",sdf.parse("01-04-2020"),sdf.parse("30-04-2020"));
Project p2= new Project(2,"AI",sdf.parse("20-04-2020"),sdf.parse("15-05-2020"));
Project p3= new Project(3,"IOT",sdf.parse("17-05-2020"),sdf.parse("21-06-2020"));
Project p4= new Project(4,"DataWareHousing",sdf.parse("05-06-2020"),sdf.parse("20-07-2020"));
Project p5= new Project(5,"Python",sdf.parse("01-04-2020"),sdf.parse("30-04-2020"));
Project p6= new Project(6,"MachineLearning",sdf.parse("11-04-2020"),sdf.parse("30-06-2020"));
Project p7= new Project(7,"Cloud",sdf.parse("24-06-2020"),sdf.parse("30-07-2020"));
Project p8= new Project(8,"BigData",sdf.parse("01-04-2020"),sdf.parse("30-04-2020"));
Project p9= new Project(9,"BlockChain",sdf.parse("02-04-2020"),sdf.parse("30-04-2020"));
Project p10= new Project(10,"RPA",sdf.parse("02-11-2020"),sdf.parse("30-12-2020"));

TreeMap<Project,Employee> map= new TreeMap<Project,Employee>();
map.put(p1,e5);
map.put(p2,e7);
map.put(p7,e8);
map.put(p3,e4);
map.put(p6,e1);
map.put(p9,e3);
map.put(p4,e2);
map.put(p5,e9);
map.put(p8,e10);
map.put(p10,e6);
//map.entrySet().stream().forEach(t->System.out.println(t));
return map;

	}
public static void displayByProjectDomain(Map<Project,Employee> map) {
	Comparator<Map.Entry<Project,Employee>> comparator= new Comparator<Map.Entry<Project,Employee>>(){

		@Override
		public int compare(Entry<Project, Employee> o1, Entry<Project, Employee> o2) {
			// TODO Auto-generated method stub
			return o1.getKey().getDomain().compareTo(o2.getKey().getDomain());
		}
		
		
	};
	map.entrySet().stream().sorted(comparator).forEach(t->System.out.println(t));
	}


	public static void displayByProjectId(Map<Project,Employee> map)
	{
		SortedMap<Project,Employee> sortedmap=new TreeMap<Project,Employee>(map);
		sortedmap.entrySet().stream().forEach(t->System.out.println(t));
	}

	public static void main(String[] args) throws ParseException
	{
		Map<Project,Employee> map= project();
	displayByProjectId(map);
	System.out.println("**************");
	displayByProjectDomain(map);
	}

}
